Prerequisiti: 
Questo applicativo necessita l'installazione di Java versione 17.

Guida:

1. Scaricare ed installare XAMPP Control Panel:
    durante l'installazione scegliere di installare almeno MySQL e PhpMyAdmin

https://www.apachefriends.org/it/index.html

2. Aprire XAMPP Control Panel

3. Avviare (in questo ordine) Apache e MySQL premendo il tasto "Start" nelle relative righe

4. Aprire http://localhost/phpmyadmin/ verremmo presentati con l'interfaccia grafica del server MySQL

5. Nella colonna di sinistra premere "Nuovo"

6. Inserire "cloudnine" come nome del nuovo database. Vedremo che si aggiungerà alla lista di sinistra

7. Premere sul nome ("cloudnine") del nuovo database nella lista

8. Dalle pagine nella parte superiore premere "Importa"

9. Nella sezione "File da importare" scegliere tramite il tasto ed il file browser il file incluso in questo pacchetto
    chiamato "cloudnine.sql", successivamente premere su "Importa"

10. Aprire il file "CloudNine.jar" e consultare l'applicativo. Si può utilizzare l'utente "bag" e la password "1" per fare log in